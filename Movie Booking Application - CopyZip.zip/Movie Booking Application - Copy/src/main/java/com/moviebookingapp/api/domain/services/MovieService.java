package com.moviebookingapp.api.domain.services;

import com.moviebookingapp.api.domain.dtos.*;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public interface MovieService {
    ApiResponseDto addMovie(AddMovieRequestDto dto);
    List<MovieResponseDto> getAllMovies();
    List<MovieResponseDto> searchMoviesByName(String name);

    ApiResponseDto updateTicketStatus(String moviename, int numberOfTickets, UpdateTicketStatusDto status);

    ApiResponseDto deleteMovie(String moviename, String id);

    List<MovieResponseDto> searchMovies(SearchMovieRequestDto searchMovieRequestDto);
}
