package com.moviebookingapp.api.domain.services;

import com.moviebookingapp.api.domain.dtos.ApiResponseDto;
import com.moviebookingapp.api.domain.dtos.ForgotPasswordRequestDto;
import com.moviebookingapp.api.domain.dtos.LoginRequestDto;
import com.moviebookingapp.api.domain.dtos.UserRequestDto;
import org.springframework.stereotype.Service;

@Service
public interface UserService {


    ApiResponseDto createUser(UserRequestDto userRequestDto);
    ApiResponseDto login(LoginRequestDto loginRequestDto);
    ApiResponseDto resetPassword(ForgotPasswordRequestDto forgotPasswordRequestDto, String username);



}

