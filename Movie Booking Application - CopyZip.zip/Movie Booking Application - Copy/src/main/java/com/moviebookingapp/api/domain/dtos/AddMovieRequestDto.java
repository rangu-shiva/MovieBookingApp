package com.moviebookingapp.api.domain.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.OptBoolean;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;



import java.util.Date;

@Data
public class AddMovieRequestDto {

    @NotBlank(message = "Movie Name cannot be blank")
    private String movieName;

    @NotBlank(message = "Theatre Name cannot be blank")
    private String theatreName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", lenient = OptBoolean.FALSE)
    @NotNull(message = "Release date is required")
    @FutureOrPresent(message = "Release date cannot be in the past")
    private Date releaseDate;

    @Min(value = 1, message = "Total tickets must be at least 1")
    private int totalTickets;

    @Min(value = 0, message = "Available tickets cannot be negative")
    @Max(value = 1000, message = "Available tickets cannot exceed 1000") // Optional upper bound
    private int ticketsAvailable;


    private String ticketStatus;

}
