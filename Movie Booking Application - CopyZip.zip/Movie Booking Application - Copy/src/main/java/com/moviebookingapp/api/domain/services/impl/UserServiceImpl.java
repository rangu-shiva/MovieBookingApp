package com.moviebookingapp.api.domain.services.impl;

import com.moviebookingapp.api.domain.dtos.ApiResponseDto;
import com.moviebookingapp.api.domain.dtos.ForgotPasswordRequestDto;
import com.moviebookingapp.api.domain.dtos.LoginRequestDto;
import com.moviebookingapp.api.domain.dtos.UserRequestDto;
import com.moviebookingapp.api.domain.entities.User;
import com.moviebookingapp.api.domain.exceptions.DuplicateUserException;
import com.moviebookingapp.api.domain.exceptions.InvalidCredentialsException;
import com.moviebookingapp.api.domain.exceptions.UserNotFoundException;
import com.moviebookingapp.api.domain.mappers.UserMapper;
import com.moviebookingapp.api.domain.repositories.UserRepository;
import com.moviebookingapp.api.domain.services.UserService;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final SequenceGeneratorService sequenceGeneratorService;
    private final UserMapper userMapper;

    public ApiResponseDto createUser(UserRequestDto userRequestDto) {
        validateUserRequestDto(userRequestDto);
        User user = userMapper.toEntity(userRequestDto);
        user.setId(sequenceGeneratorService.generateSequence(User.SEQUENCE_NAME));

        User registeredUser = userRepository.save(user);
        return new ApiResponseDto(true, "User Created Successfully with Login Id " + registeredUser.getLoginId());
    }


    @Override
    public ApiResponseDto login(LoginRequestDto loginRequestDto) {
        String username = loginRequestDto.getUserName();
        String password = loginRequestDto.getPassword();

        // Try finding user by email first, then by loginId
        Optional<User> userOptional = userRepository.findByEmail(username)
                .or(() -> userRepository.findByLoginId(username));

        if (userOptional.isEmpty()) {
            throw new InvalidCredentialsException("User not found with provided credentials");
        }

        User user = userOptional.get();

        if (user.getPassword().equals(password)) {
            return new ApiResponseDto(true,"Login successful");
        } else {
            throw new InvalidCredentialsException("Invalid password");
        }
    }

    @Override
    public ApiResponseDto resetPassword(ForgotPasswordRequestDto forgotPasswordRequestDto, String username) {

        Optional<User> userByEmail = userRepository.findByEmail(username);
        Optional<User> userByLoginId = userRepository.findByLoginId(username);

        User user = userByEmail.or(() -> userByLoginId)
                .orElseThrow(() -> new UserNotFoundException("User not found with provided credentials: " + username));

        user.setPassword(forgotPasswordRequestDto.getNewPassword());
        userRepository.save(user);

        return new ApiResponseDto(true,"Password reset successful");
    }


    private void validateUserRequestDto(UserRequestDto userRequestDto) {
        if (userRepository.findByEmail(userRequestDto.getEmail()).isPresent()) {
            throw new DuplicateUserException("Email already exists");
        }
        if (userRepository.findByLoginId(userRequestDto.getLoginId()).isPresent()) {
            throw new DuplicateUserException("Login ID already exists");
        }
    }

}
