package com.moviebookingapp.api.domain.dtos;

import lombok.Data;

import java.util.Date;
@Data
public class MovieResponseDto {
    private String id;

    private String movieName;
    private String theatreName;
    private Date releaseDate;
    private int ticketsAvailable;
    private String ticketStatus;

}
