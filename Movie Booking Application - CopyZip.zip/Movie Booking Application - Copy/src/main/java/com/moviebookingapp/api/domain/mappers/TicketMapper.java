package com.moviebookingapp.api.domain.mappers;

import com.moviebookingapp.api.domain.dtos.MovieBookingRequestDto;
import com.moviebookingapp.api.domain.entities.Ticket;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface TicketMapper {

    @Named("toTicket")
    @Mapping(target = "ticketId", ignore = true)
    @Mapping(target = "movieName", source = "movieName")
    Ticket toTicket(MovieBookingRequestDto dto, String movieName);
}
