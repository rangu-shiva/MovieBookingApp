package com.moviebookingapp.api.domain.dtos;

import lombok.Data;

import java.util.Date;
@Data
public class SearchMovieRequestDto {

    private String movieName;
    private Date showDate;

}
