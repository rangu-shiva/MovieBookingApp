package com.moviebookingapp.api.domain.repositories;

import com.moviebookingapp.api.domain.entities.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface UserRepository extends MongoRepository<User, String> {
    Optional<User> findByEmail(String email);
    Optional<User> findByLoginId(String loginId);
}
