package com.moviebookingapp.api.domain.services;


import com.moviebookingapp.api.domain.dtos.ApiResponseDto;
import com.moviebookingapp.api.domain.dtos.MovieBookingRequestDto;
import org.springframework.stereotype.Service;

@Service
public interface MovieBookingService {
    ApiResponseDto bookMovieTicket(MovieBookingRequestDto movieBookingRequestDto, String moviename);
}
