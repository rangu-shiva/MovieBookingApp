package com.moviebookingapp.api.domain.dtos;

import lombok.Data;

import java.time.LocalDate;

@Data
public class BookingSummaryResponseDto {
    private String loginId;
    private String movieName;
    private String theatreName;
    private LocalDate showDate;
    private String seat;


}
