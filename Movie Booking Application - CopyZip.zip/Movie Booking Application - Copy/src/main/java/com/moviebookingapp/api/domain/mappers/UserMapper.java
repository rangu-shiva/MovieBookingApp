package com.moviebookingapp.api.domain.mappers;

import com.moviebookingapp.api.domain.dtos.UserRequestDto;
import com.moviebookingapp.api.domain.entities.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface UserMapper {

    @Mapping(target = "id", ignore = true)
    User toEntity(UserRequestDto dto);
}
