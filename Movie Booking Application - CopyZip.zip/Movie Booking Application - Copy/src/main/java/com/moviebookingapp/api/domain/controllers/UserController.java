package com.moviebookingapp.api.domain.controllers;

import com.moviebookingapp.api.domain.constants.ApiEndPoints;
import com.moviebookingapp.api.domain.dtos.ApiResponseDto;
import com.moviebookingapp.api.domain.dtos.ForgotPasswordRequestDto;
import com.moviebookingapp.api.domain.dtos.LoginRequestDto;
import com.moviebookingapp.api.domain.dtos.UserRequestDto;
import com.moviebookingapp.api.domain.services.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(ApiEndPoints.BASE_URL)
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final UserService userService;

    @PostMapping(path = ApiEndPoints.REGISTER_USER, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponseDto> createUser(@Valid @RequestBody UserRequestDto userRequestDto) {
        log.info("Registering user: {}", userRequestDto.getLoginId());
        ApiResponseDto response = userService.createUser(userRequestDto);
        log.debug("Registration response: {}", response);
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = ApiEndPoints.USER_LOGIN, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponseDto> login(@Valid @RequestBody LoginRequestDto loginRequestDto) {
        log.info("Login attempt for user: {}", loginRequestDto.getUserName());
        ApiResponseDto response = userService.login(loginRequestDto);
        log.debug("Login response: {}", response);
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = ApiEndPoints.FORGOT_PASSWORD, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponseDto> resetPassword(@Valid @RequestBody ForgotPasswordRequestDto forgotPasswordRequestDto, @PathVariable String username) {
        log.info("Password reset requested for user: {}", username);
        ApiResponseDto response = userService.resetPassword(forgotPasswordRequestDto, username);
        log.debug("Password reset response: {}", response);
        return ResponseEntity.ok(response);
    }
}
