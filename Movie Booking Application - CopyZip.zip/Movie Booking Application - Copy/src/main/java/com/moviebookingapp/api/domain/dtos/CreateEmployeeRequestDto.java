package com.moviebookingapp.api.domain.dtos;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class CreateEmployeeRequestDto {
    @NotBlank(message = "Employee name cannot be blank")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Employee name must contain only letters")
    private String employeeName;

    @NotBlank(message = "Role cannot be blank")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Role must contain only letters")
    private String role;

    @NotBlank(message = "Location cannot be blank")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Location must contain only letters")
    private String location;

    @NotBlank(message = "Email ID cannot be blank")
    @Email(message = "Invalid email format")
    private String emailId;

    @NotBlank(message = "Mobile number cannot be blank")
    @Pattern(regexp = "^[0-9]{10}$", message = "Mobile number must be exactly 10 digits")
    private String mobileNumber;


}
