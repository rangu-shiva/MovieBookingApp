package com.moviebookingapp.api.domain.mappers;

import com.moviebookingapp.api.domain.dtos.MovieBookingRequestDto;
import com.moviebookingapp.api.domain.entities.Seat;
import com.moviebookingapp.api.domain.entities.Movie;
import org.mapstruct.Mapper;

import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SeatMapper {
//
//    @Named("mapSeats")
//    List<Seat> toSeatEntities(Movie movie, List<Integer> seatNumbers, String ticketId, String movieName, MovieBookingRequestDto bookingDto);
}
