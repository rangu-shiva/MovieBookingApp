package com.moviebookingapp.api.domain.controllers;

import com.moviebookingapp.api.domain.constants.ApiEndPoints;
import com.moviebookingapp.api.domain.dtos.ApiResponseDto;
import com.moviebookingapp.api.domain.dtos.MovieBookingRequestDto;
import com.moviebookingapp.api.domain.services.MovieBookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping(ApiEndPoints.BASE_URL)
@RequiredArgsConstructor
@Slf4j
public class MovieBookingController {

    private MovieBookingService movieBookingService;

    @PostMapping(path = ApiEndPoints.BOOK_MOVIE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponseDto> bookMovieTicket(@Valid @RequestBody MovieBookingRequestDto movieBookingRequestDto, @PathVariable String movieName) {
        log.info("Received booking request for movie: {}, theatre: {}, tickets: {}", movieName, movieBookingRequestDto.getTheatreName(), movieBookingRequestDto.getNumberOfTickets());
        ApiResponseDto response = movieBookingService.bookMovieTicket(movieBookingRequestDto, movieName);
        log.info("Booking response: message={}", response.getMessage());
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(response);

    }
}
