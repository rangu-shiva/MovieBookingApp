package com.moviebookingapp.api.domain.dtos;

import lombok.Data;

@Data
public class CreateEmployeeResponseDto {
    private String id;
    private String employeeName;
    private String role;
    private String location;
    private String emailId;
    private String mobileNumber;

}
