package com.moviebookingapp.api.domain.repositories;

import com.moviebookingapp.api.domain.entities.Seat;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface SeatRepository extends MongoRepository<Seat,String> {
    List<Seat> findByMovieNameAndTheatreNameAndShowDate(String moviename, String theatreName, Date showDate);

}