package com.moviebookingapp.api.domain.repositories;

import com.moviebookingapp.api.domain.entities.Seat;
import com.moviebookingapp.api.domain.entities.Ticket;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface TicketRepository extends MongoRepository<Ticket,String> {

    Optional<Ticket> findByTicketIdAndMovieName(String ticketId, String movieName);

}
