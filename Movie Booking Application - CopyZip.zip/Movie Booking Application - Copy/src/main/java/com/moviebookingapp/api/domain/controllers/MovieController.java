package com.moviebookingapp.api.domain.controllers;

import com.moviebookingapp.api.domain.constants.ApiEndPoints;
import com.moviebookingapp.api.domain.dtos.*;
import com.moviebookingapp.api.domain.services.MovieService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(ApiEndPoints.BASE_URL)
@RequiredArgsConstructor
@Slf4j
public class MovieController {

    private final MovieService movieService;

    @PostMapping(path = ApiEndPoints.ADD_NEW_MOVIE, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponseDto> addMovie(@Valid @RequestBody AddMovieRequestDto addMovieRequestDto) {
        log.info("Adding new movie: {}", addMovieRequestDto.getMovieName());
        return ResponseEntity.ok(movieService.addMovie(addMovieRequestDto));
    }

    @GetMapping(path = ApiEndPoints.VIEW_ALL_MOVIES, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<MovieResponseDto>> getAllMovies() {
        log.info("Fetching all movies");
        return ResponseEntity.ok(movieService.getAllMovies());
    }

    @GetMapping(path = ApiEndPoints.RETRIEVE_BY_MOVIE_NAME, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<MovieResponseDto>> searchMovies(@PathVariable String movieName) {
        log.info("Searching movies by name: {}", movieName);
        return ResponseEntity.ok(movieService.searchMoviesByName(movieName));
    }

    @PutMapping(path = ApiEndPoints.UPDATE_TICKET_STATUS, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponseDto> updateTicketStatus(@PathVariable String movieName, @PathVariable int tickets, @RequestBody UpdateTicketStatusDto updateTicketStatusDto) {
        log.info("Updating ticket status for movie: {}, tickets: {}", movieName, tickets);
        return ResponseEntity.ok(movieService.updateTicketStatus(movieName, tickets, updateTicketStatusDto));
    }

    @DeleteMapping(path = ApiEndPoints.DELETE_MOVIE, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponseDto> deleteMovie(@PathVariable String movieName, @PathVariable String id) {
        log.info("Deleting movie: {}, ID: {}", movieName, id);
        return ResponseEntity.ok(movieService.deleteMovie(movieName, id));
    }

    @GetMapping(path = ApiEndPoints.SEARCH_MOVIES, produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<MovieResponseDto>> searchMovie(@RequestBody SearchMovieRequestDto searchMovieRequestDto) {
        log.info("Searching movies with criteria: {}", searchMovieRequestDto);
        return ResponseEntity.ok(movieService.searchMovies(searchMovieRequestDto));
    }
}
