package com.moviebookingapp.api.domain.repositories;

import com.moviebookingapp.api.domain.entities.Movie;
import com.moviebookingapp.api.domain.entities.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface MovieRepository extends MongoRepository<Movie, String> {
    Optional<Movie> findByMovieNameAndTheatreName(String movieName, String theatreName);
    void deleteByIdAndMovieName(String id, String name);


    List<Movie> findByMovieNameContainingIgnoreCase(String name);
}
