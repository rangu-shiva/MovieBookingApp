package com.moviebookingapp.api.domain.dtos;

import lombok.Data;

@Data
public class ForgotPasswordRequestDto {
    private String newPassword;
    private String confirmPassword;
}
