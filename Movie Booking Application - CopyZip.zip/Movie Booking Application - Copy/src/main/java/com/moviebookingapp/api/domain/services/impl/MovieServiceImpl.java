package com.moviebookingapp.api.domain.services.impl;

import com.moviebookingapp.api.domain.dtos.AddMovieRequestDto;
import com.moviebookingapp.api.domain.dtos.ApiResponseDto;
import com.moviebookingapp.api.domain.dtos.MovieResponseDto;
import com.moviebookingapp.api.domain.dtos.UpdateTicketStatusDto;
import com.moviebookingapp.api.domain.dtos.SearchMovieRequestDto;
import com.moviebookingapp.api.domain.entities.Movie;

import com.moviebookingapp.api.domain.entities.Seat;
import com.moviebookingapp.api.domain.exceptions.InvalidDataException;
import com.moviebookingapp.api.domain.exceptions.MovieAlreadyExistsException;
import com.moviebookingapp.api.domain.exceptions.MovieNotFoundException;
import com.moviebookingapp.api.domain.mappers.MovieMapper;
import com.moviebookingapp.api.domain.repositories.MovieRepository;
import com.moviebookingapp.api.domain.repositories.SeatRepository;
import com.moviebookingapp.api.domain.repositories.TicketRepository;
import com.moviebookingapp.api.domain.services.MovieService;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MovieServiceImpl implements MovieService {

    private final MovieRepository movieRepository;
    private final SeatRepository seatRepository;
    private final MovieMapper movieMapper;

    public ApiResponseDto addMovie( AddMovieRequestDto addMovieRequestDto) {

        Optional<Movie> existingMovie = movieRepository.findByMovieNameAndTheatreName(addMovieRequestDto.getMovieName(), addMovieRequestDto.getTheatreName());
        if (existingMovie.isPresent()) {
            throw new MovieAlreadyExistsException("Movie '" + addMovieRequestDto.getMovieName()+ "' already exists in theatre '" + addMovieRequestDto.getTheatreName() + "'");
        }

        if (addMovieRequestDto.getReleaseDate().before(new Date())) {
            throw new InvalidDataException("Release date cannot be in the past");
        }

        if (addMovieRequestDto.getTotalTickets() <= 0) {
            throw new InvalidDataException("Total tickets must be greater than zero");
        }

        Movie movie = movieMapper.mapToMovieEntity(addMovieRequestDto);

        movieRepository.save(movie);
        return new ApiResponseDto(true, "Movie added successfully");
    }




    public ApiResponseDto deleteMovie(String moviename, String movieId) {
        Optional<Movie> movie = movieRepository.findById(movieId);
        if (movie.isEmpty() || !movie.get().getMovieName().equals(moviename)) {
            throw new MovieNotFoundException("Movie not found with given name and ID");
        }

        movieRepository.deleteByIdAndMovieName(movieId, moviename);
        return new ApiResponseDto(true, "Movie deleted successfully");
    }

    public List<MovieResponseDto> getAllMovies() {
        List<Movie> movies = movieRepository.findAll();
        if (movies.isEmpty()) {
            throw new MovieNotFoundException("No movies found");
        }
        return movies.stream().map(movieMapper::mapToDto).collect(Collectors.toList());
    }

    public List<MovieResponseDto> searchMoviesByName(String name) {
        List<Movie> movies = movieRepository.findByMovieNameContainingIgnoreCase(name);
        if (movies.isEmpty()) {
            throw new MovieNotFoundException("No movies found with name: " + name);
        }
        return movies.stream().map(movieMapper::mapToDto).collect(Collectors.toList());
    }

    public ApiResponseDto updateTicketStatus(String movieName, int numberOfTickets, UpdateTicketStatusDto updateTicketStatusDto) {
        Movie movie = movieRepository.findByMovieNameAndTheatreName(movieName, updateTicketStatusDto.getTheatreName())
                .orElseThrow(() -> new MovieNotFoundException("Movie '" + movieName + "' not found in theatre '" + updateTicketStatusDto.getTheatreName() + "'"));

        if (numberOfTickets < 0) {
            throw new InvalidDataException("Available tickets cannot be negative");
        }

        movie.setTicketsAvailable(numberOfTickets);
        movie.setTotalTickets(numberOfTickets);
        movie.setTicketStatus(updateTicketStatusDto.getStatus().toUpperCase());
        movieRepository.save(movie);
        return new ApiResponseDto(true, "Ticket status updated successfully");
    }



    public List<MovieResponseDto> searchMovies(SearchMovieRequestDto searchMovieRequestDto) {
        List<Movie> movies = movieRepository.findByMovieNameContainingIgnoreCase(searchMovieRequestDto.getMovieName());
        if (movies.isEmpty()) {
            throw new MovieNotFoundException("No movies found with name: " + searchMovieRequestDto.getMovieName());
        }
        List<MovieResponseDto> list = new ArrayList<MovieResponseDto>();
        for (Movie movie : movies) {
            List<Seat> seats = seatRepository.findByMovieNameAndTheatreNameAndShowDate(
                    movie.getMovieName(), movie.getTheatreName(), searchMovieRequestDto.getShowDate());

            int numberOfSeatsBooked = seats.size();
            MovieResponseDto dto = movieMapper.toDto(movie, numberOfSeatsBooked);
            list.add(dto);
        }
        return list;

    }

}
