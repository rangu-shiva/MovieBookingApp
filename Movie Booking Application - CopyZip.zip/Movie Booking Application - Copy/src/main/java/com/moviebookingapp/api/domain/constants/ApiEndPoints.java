package com.moviebookingapp.api.domain.constants;

public class ApiEndPoints {

    // Base Url
    public static final String BASE_URL = "/api/v1.0/moviebooking";

    // User-related endpoints
    public static final String REGISTER_USER = "/register";
    public static final String USER_LOGIN = "/login";
    public static final String FORGOT_PASSWORD = "/{username}/forgot";
    public static final String VIEW_ALL_MOVIES = "/all";
    public static final String RETRIEVE_BY_MOVIE_NAME = "/movies/search/{movieName}";
    public static final String BOOK_MOVIE = "/{movieName}/book";

    // Admin-related endpoints
    public static final String ADD_NEW_MOVIE = "/addMovie";
    public static final String UPDATE_TICKET_STATUS = "/{movieName}/update/{tickets}";
    public static final String DELETE_MOVIE = "/{movieName}/delete/{id}";

    public static final String SEARCH_MOVIES  = "/movies/search";



}
