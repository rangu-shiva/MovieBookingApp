package com.moviebookingapp.api.domain.services.impl;

import com.moviebookingapp.api.domain.dtos.ApiResponseDto;
import com.moviebookingapp.api.domain.dtos.MovieBookingRequestDto;
import com.moviebookingapp.api.domain.entities.Movie;
import com.moviebookingapp.api.domain.entities.Seat;
import com.moviebookingapp.api.domain.entities.Ticket;
import com.moviebookingapp.api.domain.exceptions.MovieNotFoundException;
import com.moviebookingapp.api.domain.mappers.TicketMapper;
import com.moviebookingapp.api.domain.repositories.MovieRepository;
import com.moviebookingapp.api.domain.repositories.SeatRepository;
import com.moviebookingapp.api.domain.repositories.TicketRepository;
import com.moviebookingapp.api.domain.services.MovieBookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@RequiredArgsConstructor
public class MovieBookingServiceImpl implements MovieBookingService {

    private final MovieRepository movieRepository;
    private final SeatRepository seatRepository;
    private final TicketRepository ticketRepository;
    private final TicketMapper ticketMapper;

    public ApiResponseDto bookMovieTicket(MovieBookingRequestDto movieBookingRequestDto, String moviename){


        Optional<Movie> optionalMovie = movieRepository.findByMovieNameAndTheatreName(moviename,movieBookingRequestDto.getTheatreName());
        if(optionalMovie.isEmpty()){
            throw new MovieNotFoundException("movie not found");
        }
        Movie movie = optionalMovie.get();
        String theatreName = movieBookingRequestDto.getTheatreName();
        Date showDate = movieBookingRequestDto.getShowDate();
        validateShowDate(showDate,movie.getReleaseDate());
        List<Seat> seat =  seatRepository.findByMovieNameAndTheatreNameAndShowDate(moviename,theatreName,showDate);
        int numberOfSeatsBooked = seat.size();
        List<Integer>  seats = bookTickets(numberOfSeatsBooked,movieBookingRequestDto);
        String ticketId = updateTicketDetails(movie,movieBookingRequestDto,moviename);
        updateSeatDetails(movie,seats,ticketId,moviename,movieBookingRequestDto);
//        updateMovieDetails(movie,movieBookingRequestDto,numberOfSeatsBooked);

        return new ApiResponseDto(true,"Booking Successful with Booking Id" + ticketId);
    }

    private void updateSeatDetails(Movie movie, List<Integer> seats, String ticketId, String moviename, MovieBookingRequestDto movieBookingRequestDto) {
        List<Seat> seatEntities = seats.stream()
                .map(seatNumber -> {
                    Seat seat = new Seat();
                    seat.setSeatNumber(seatNumber);
                    seat.setMovieName(moviename);
                    seat.setTheatreName(movie.getTheatreName());
                    seat.setBooked(true);
                    seat.setTicketId(ticketId);
                    seat.setShowDate(movieBookingRequestDto.getShowDate()); // Or another showDate if available
                    return seat;
                })
                .collect(Collectors.toList());

        seatRepository.saveAll(seatEntities);
    }

    private String updateTicketDetails(Movie movie, MovieBookingRequestDto movieBookingRequestDto, String moviename) {

        Ticket ticket = ticketMapper.toTicket(movieBookingRequestDto, moviename);
        Ticket savedTicket = ticketRepository.save(ticket);
        return savedTicket.getTicketId();
    }

//    private void updateMovieDetails(Movie movie, MovieBookingRequestDto movieBookingRequestDto, int numberOfSeatsBooked) {
//        movie.setTicketsAvailable(movie.getTicketsAvailable() - movieBookingRequestDto.getNumberOfTickets());
//        movieRepository.save(movie);
//    }

    private List<Integer>  bookTickets(int numberOfSeatsBooked, MovieBookingRequestDto movieBookingRequestDto) {
        return IntStream.rangeClosed(numberOfSeatsBooked + 1, numberOfSeatsBooked + movieBookingRequestDto.getNumberOfTickets())
                .boxed()
                .collect(Collectors.toList());
    }

    private void validateShowDate(Date showDate, Date releaseDate) {
        if (showDate == null || releaseDate == null) {
            throw new IllegalArgumentException("Show date and release date must not be null");
        }

        long millisInADay = 24 * 60 * 60 * 1000L;
        long diffInMillis = showDate.getTime() - releaseDate.getTime();
        long diffInDays = diffInMillis / millisInADay;

        if (diffInDays < 0) {
            throw new IllegalArgumentException("Show date cannot be before the release date");
        }

        if (diffInDays > 10) {
            throw new IllegalArgumentException("Show date must be within 10 days of the release date");
        }
    }


}
