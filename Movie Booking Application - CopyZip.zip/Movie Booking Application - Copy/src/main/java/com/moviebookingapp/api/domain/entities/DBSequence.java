package com.moviebookingapp.api.domain.entities;

import org.springframework.data.annotation.Id;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "db_sequence")
public class DBSequence {

    @Id
    private String id;
    private Long seq;

    public DBSequence(String id, Long seq) {
        this.id = id;
        this.seq = seq;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setSeq(Long seq) {
        this.seq = seq;
    }

    public String getId() {
        return id;
    }

    public Long getSeq() {
        return seq;
    }
}
