package com.moviebookingapp.api.domain.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class UpdateTicketStatusDto {
    @NotBlank(message = "Theatre name cannot be blank")
    private String theatreName;

    @NotBlank(message = "Ticket status cannot be blank")
    @Pattern(regexp = "AVAILABLE|BOOKED|CANCELLED", message = "Status must be AVAILABLE, BOOKED, or CANCELLED")
    private String status;

}
