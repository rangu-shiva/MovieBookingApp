package com.moviebookingapp.api.domain.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.OptBoolean;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.Date;
@Data
public class MovieBookingRequestDto {

    @NotBlank(message = "Theatre name is required")
    private String theatreName;

    @NotBlank(message = "User ID is required")
    private String userId;

    @Min(value = 1, message = "At least one ticket must be booked")
    @Max(value = 10, message = "Cannot book more than 10 tickets at once") // Optional upper bound
    private int numberOfTickets;

    @NotNull(message = "Show date is required")
    @FutureOrPresent(message = "Show date must be today or in the future")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", lenient = OptBoolean.FALSE)
    private Date showDate;

}
