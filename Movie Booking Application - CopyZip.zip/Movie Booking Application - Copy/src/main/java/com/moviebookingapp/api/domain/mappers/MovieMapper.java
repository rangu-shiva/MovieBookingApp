package com.moviebookingapp.api.domain.mappers;

import com.moviebookingapp.api.domain.dtos.AddMovieRequestDto;
import com.moviebookingapp.api.domain.dtos.MovieResponseDto;
import com.moviebookingapp.api.domain.entities.Movie;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface MovieMapper {

    @Mapping(target = "ticketsAvailable", expression = "java(movie.getTotalTickets() - numberOfSeatsBooked)")
    MovieResponseDto toDto(Movie movie, int numberOfSeatsBooked);
    MovieResponseDto mapToDto(Movie movie);

    @Mapping(source = "ticketsAvailable", target = "ticketsAvailable")
    @Mapping(source = "ticketStatus", target = "ticketStatus")
    Movie mapToMovieEntity(AddMovieRequestDto addMovieRequestDto);
}
